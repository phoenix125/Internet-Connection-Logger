Internet Connection Logger - Polls up to 99 websites and logs connection status 
- Latest version: Internet Connection Logger v1.0 (2020-04-23)
- By Phoenix125 | http://www.Phoenix125.com | http://discord.gg/EU7pzPs | kim@kim125.com

----------
 FEATURES
----------
- Free Open Source program.
- Polls up to 99 websites.  I personally use Google as a baseline and then my desired websites.
- Log files:
	1. All polling response. Creates new log file every calendar day.
	2. Separate website change-in-status log files.
- User-definable polling interval. Default is 60 seconds.
- Four (4) levels of logging details

-----------------
 GETTING STARTED
-----------------
- Run "Internet Connection Logger.exe"
- A Internet Connection Logger.ini" file will be created. Make any desired changes to this file.
- If you change the number of websites to monitor, you will have to re-run the program to create the new entries.
- After all desired changes have been made, 


----------------
 DOWNLOAD LINKS
----------------
Latest Version:    http://www.phoenix125.com/share/ICL/Internet_Connection_Logger.zip
GitHub:	           https://github.com/phoenix125/Internet-Connection-Logger

Website: http://www.Phoenix125.com
Discord: http://discord.gg/EU7pzPs
Forum:   https://phoenix125.createaforum.com/index.php

Other programs: 
- Atlas Server Update Utility
- 7 Days To Die Server Update Utility
- 7 Days To Die Map Analyzer
- Conan Exiles Server Update Utility


---------
 VERSION HISTORY
---------
(2020-04-23) v1.0 Initial Release
- Free Open Source program.
- Polls up to 99 websites.  I personally use Google as a baseline and then my desired websites.
- Log files:
	1. All polling response. Creates new log file every calendar day.
	2. Separate website change-in-status log files.
- User-definable polling interval. Default is 60 seconds.
- Four (4) levels of logging details
